(function () {
    var t = document && document.currentScript && document.currentScript.src;
    (window.webpackJsonpruntime = window.webpackJsonpruntime || []).push([[15], {
        "c/Wg": function (i, n, a) {
            "use strict";
            a.r(n);
            var _ = a("7uCZ"), u = a.n(_), d = a("J3gS"), m = a.n(d);
            a.d(n, "DudaAnimationManager", function () {
                return d.DudaAnimationManager
            })
        }
    }])
})();
